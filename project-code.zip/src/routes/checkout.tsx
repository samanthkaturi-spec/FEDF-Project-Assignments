import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Checkout — Royal Stay" }] }),
  component: () => (<AuthGate><Checkout /></AuthGate>),
});

function Checkout() {
  const { items, subtotal, gst, service, total, clear } = useCart();
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [notes, setNotes] = useState("");
  const [payment, setPayment] = useState<"cod" | "credit_card">("cod");
  const [room, setRoom] = useState(profile?.room_number ?? "");
  const [placing, setPlacing] = useState(false);

  async function place() {
    if (!user) return;
    if (items.length === 0) return toast.error("Cart is empty");
    if (!room.trim()) return toast.error("Room number is required");
    setPlacing(true);
    const { data: order, error } = await supabase
      .from("orders")
      .insert({
        user_id: user.id,
        room_number: room,
        subtotal, gst, service_charge: service, total,
        notes,
        payment_method: payment,
        payment_status: payment === "credit_card" ? "paid" : "pending",
        status: "confirmed",
      })
      .select()
      .single();
    if (error || !order) { setPlacing(false); return toast.error(error?.message ?? "Could not place order"); }
    const rows = items.map((i) => ({
      order_id: order.id, menu_item_id: i.id, name_snapshot: i.name,
      price_snapshot: i.price, quantity: i.quantity,
    }));
    const { error: oiErr } = await supabase.from("order_items").insert(rows);
    setPlacing(false);
    if (oiErr) return toast.error(oiErr.message);
    clear();
    toast.success("Order confirmed — preparing now");
    navigate({ to: "/order/$id", params: { id: order.id } });
  }

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-6 py-10">
        <h1 className="mb-8 font-display text-4xl">Checkout</h1>
        <div className="glass space-y-6 rounded-3xl p-6">
          <label className="block">
            <span className="text-xs uppercase tracking-wider text-muted-foreground">Room number</span>
            <input value={room} onChange={(e) => setRoom(e.target.value)} className="mt-1 w-full rounded-xl border border-border bg-background/40 px-4 py-2.5 text-sm outline-none focus:border-primary" />
          </label>
          <label className="block">
            <span className="text-xs uppercase tracking-wider text-muted-foreground">Special instructions</span>
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3}
              placeholder="Allergies, preferences, delivery time…"
              className="mt-1 w-full rounded-xl border border-border bg-background/40 px-4 py-2.5 text-sm outline-none focus:border-primary" />
          </label>
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Payment</div>
            <div className="mt-2 grid grid-cols-2 gap-3">
              {(["cod", "credit_card"] as const).map((p) => (
                <button key={p} onClick={() => setPayment(p)}
                  className={`rounded-xl border p-4 text-left text-sm transition ${payment === p ? "border-primary bg-primary/10" : "border-border glass"}`}>
                  <div className="font-display text-base">{p === "cod" ? "Charge to room" : "Card (demo)"}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{p === "cod" ? "Settle at checkout" : "Always-approve demo"}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl bg-background/40 p-5 text-sm">
            <Row label="Subtotal" v={subtotal} />
            <Row label="GST (5%)" v={gst} />
            <Row label="Service charge (10%)" v={service} />
            <div className="my-3 border-t border-border/40" />
            <Row label="Total payable" v={total} bold />
          </div>

          <button disabled={placing || items.length === 0}
            onClick={place}
            className="w-full rounded-full bg-primary py-3.5 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-60">
            {placing ? "Placing order…" : `Confirm order · ₹${total.toFixed(0)}`}
          </button>
        </div>
      </main>
    </div>
  );
}
function Row({ label, v, bold }: { label: string; v: number; bold?: boolean }) {
  return (
    <div className={`flex justify-between py-1 ${bold ? "font-display text-base" : "text-muted-foreground"}`}>
      <span>{label}</span><span className={bold ? "text-primary" : "text-foreground"}>₹{v.toFixed(2)}</span>
    </div>
  );
}