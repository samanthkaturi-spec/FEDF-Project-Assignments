import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { useCart } from "@/lib/cart";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Your Cart — Royal Stay" }] }),
  component: () => (<AuthGate><CartPage /></AuthGate>),
});

function CartPage() {
  const { items, setQty, remove, subtotal, gst, service, total } = useCart();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-4xl px-6 py-10">
        <h1 className="mb-8 font-display text-4xl">Your <span className="text-gradient-gold">Cart</span></h1>
        {items.length === 0 ? (
          <div className="glass grid place-items-center rounded-3xl px-6 py-20 text-center">
            <ShoppingBag className="mb-4 h-10 w-10 text-muted-foreground" />
            <p className="text-muted-foreground">Your cart is empty</p>
            <Link to="/room-service" className="mt-6 rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90">
              Browse menu
            </Link>
          </div>
        ) : (
          <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
            <div className="space-y-3">
              {items.map((it) => (
                <div key={it.id} className="glass flex items-center gap-4 rounded-2xl p-4">
                  <img src={it.image_url} alt={it.name} className="h-20 w-20 rounded-xl object-cover" />
                  <div className="flex-1 min-w-0">
                    <div className="font-display text-lg">{it.name}</div>
                    <div className="text-sm text-primary">₹{Number(it.price).toFixed(0)}</div>
                  </div>
                  <div className="flex items-center gap-2 rounded-full glass px-1.5 py-1">
                    <button onClick={() => setQty(it.id, it.quantity - 1)} className="grid h-7 w-7 place-items-center rounded-full bg-background/60 hover:bg-primary hover:text-primary-foreground">
                      <Minus className="h-3 w-3" />
                    </button>
                    <span className="min-w-6 text-center text-sm">{it.quantity}</span>
                    <button onClick={() => setQty(it.id, it.quantity + 1)} className="grid h-7 w-7 place-items-center rounded-full bg-background/60 hover:bg-primary hover:text-primary-foreground">
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                  <button onClick={() => remove(it.id)} className="rounded-full p-2 text-muted-foreground hover:text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
            <aside className="glass h-fit rounded-2xl p-6">
              <h2 className="font-display text-xl">Bill summary</h2>
              <dl className="mt-5 space-y-2 text-sm">
                <Row label="Subtotal" value={subtotal} />
                <Row label="GST (5%)" value={gst} />
                <Row label="Service charge (10%)" value={service} />
                <div className="my-3 border-t border-border/40" />
                <Row label="Total" value={total} bold />
              </dl>
              <button
                onClick={() => navigate({ to: "/checkout" })}
                className="mt-6 w-full rounded-full bg-primary py-3 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                Proceed to checkout
              </button>
            </aside>
          </div>
        )}
      </main>
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: number; bold?: boolean }) {
  return (
    <div className={`flex justify-between ${bold ? "font-display text-base" : "text-muted-foreground"}`}>
      <dt>{label}</dt>
      <dd className={bold ? "text-primary" : "text-foreground"}>₹{value.toFixed(2)}</dd>
    </div>
  );
}