import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, ScanLine, UtensilsCrossed, BellRing } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Royal Stay Concierge — Scan. Order. Relax." },
      { name: "description", content: "A luxury in-room digital concierge. Order food, request housekeeping, book spa." },
      { property: "og:title", content: "Royal Stay Concierge" },
      { property: "og:description", content: "Scan. Order. Relax. Your private 5-star concierge." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <div
        className="absolute inset-0 -z-10 bg-cover bg-center opacity-40"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1920')" }}
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-background/70 via-background/85 to-background" />

      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-full glass-strong">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div className="font-display text-xl font-semibold tracking-wide">
            Royal Stay <span className="text-gradient-gold">Concierge</span>
          </div>
        </div>
        <nav className="hidden gap-6 text-sm text-muted-foreground sm:flex">
          <Link to="/login" className="hover:text-primary transition-colors">Sign in</Link>
          <Link to="/register" className="hover:text-primary transition-colors">Register</Link>
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-6 pb-24 pt-12 sm:pt-20">
        <div className="max-w-3xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs uppercase tracking-[0.2em] text-primary">
            <ScanLine className="h-3.5 w-3.5" /> In-room digital concierge
          </div>
          <h1 className="font-display text-5xl font-medium leading-[1.05] sm:text-7xl">
            Scan. <span className="text-gradient-gold">Order.</span> Relax.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Your private 5-star concierge — every comfort, request, and indulgence,
            curated in seconds from the palm of your hand.
          </p>

          <div className="mt-10 flex flex-wrap gap-4">
            <Link
              to="/login"
              className="rounded-full bg-primary px-7 py-3 text-sm font-medium text-primary-foreground transition hover:opacity-90 hover-lift"
            >
              Enter your suite
            </Link>
            <Link
              to="/register"
              className="rounded-full glass px-7 py-3 text-sm font-medium text-foreground transition hover:border-primary"
            >
              New guest registration
            </Link>
          </div>
        </div>

        <div className="mt-20 grid gap-5 sm:grid-cols-3">
          {[
            { icon: UtensilsCrossed, title: "Room Service", desc: "Michelin-grade dining delivered to your door." },
            { icon: BellRing, title: "Housekeeping & Spa", desc: "Effortless requests, immaculate service." },
            { icon: Sparkles, title: "Concierge", desc: "Anything you can imagine, arranged with grace." },
          ].map((f) => (
            <div key={f.title} className="glass rounded-2xl p-6 hover-lift">
              <f.icon className="mb-4 h-6 w-6 text-primary" />
              <div className="font-display text-xl">{f.title}</div>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}