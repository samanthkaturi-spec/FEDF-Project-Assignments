import { createFileRoute } from "@tanstack/react-router";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { MapPin, Clock, Ticket, Utensils, Mountain, Film, Compass } from "lucide-react";

export const Route = createFileRoute("/concierge")({
  head: () => ({ meta: [{ title: "Concierge — Royal Stay" }] }),
  component: () => (<AuthGate><Concierge /></AuthGate>),
});

const attractions = [
  { name: "Historical Fort", desc: "16th-century fortress with panoramic city views.", distance: "4.2 km", time: "12 min", img: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=800" },
  { name: "City Museum", desc: "Curated heritage galleries & rotating exhibits.", distance: "2.1 km", time: "8 min", img: "https://images.unsplash.com/photo-1565060169187-5284a3f5e69b?w=800" },
  { name: "Botanical Garden", desc: "60-acre garden with rare orchid collection.", distance: "5.6 km", time: "16 min", img: "https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?w=800" },
  { name: "Lake View Point", desc: "Sunset views across the historic lake.", distance: "7.8 km", time: "22 min", img: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=800" },
  { name: "Cultural Heritage Center", desc: "Live folk performances every evening.", distance: "3.4 km", time: "11 min", img: "https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=800" },
];
const cinemas = [
  { name: "PVR Cinemas", distance: "1.8 km", now: "Dune: Part Two · Oppenheimer · Animal" },
  { name: "INOX Multiplex", distance: "3.2 km", now: "12th Fail · Tiger 3 · Salaar" },
  { name: "Cinepolis", distance: "4.6 km", now: "Fighter · Bramayugam · Article 370" },
];
const family = [
  { name: "Wonderla Amusement Park", desc: "75+ rides, water & dry attractions.", distance: "18 km", timings: "11 AM – 7 PM", fee: "₹1,499" },
  { name: "Snow World", desc: "Sub-zero arctic playground for all ages.", distance: "8 km", timings: "10 AM – 9 PM", fee: "₹699" },
  { name: "Adventure Park", desc: "Zip-lines, paintball & obstacle course.", distance: "12 km", timings: "9 AM – 6 PM", fee: "₹899" },
  { name: "Water Kingdom", desc: "Wave pool, slides & lazy river.", distance: "22 km", timings: "10:30 AM – 6 PM", fee: "₹1,299" },
];
const dining = [
  { name: "Le Cirque", desc: "Fine dining · French-Italian", distance: "1.2 km" },
  { name: "Indian Accent", desc: "Fine dining · Modern Indian", distance: "2.4 km" },
  { name: "Blue Tokai", desc: "Café · Specialty coffee", distance: "0.6 km" },
  { name: "Third Wave", desc: "Café · Brunch & pastries", distance: "1.1 km" },
  { name: "Chandni Chowk Lane", desc: "Street food · Iconic chaats & kebabs", distance: "5.3 km" },
  { name: "VV Puram Food Street", desc: "Street food · 20+ stalls every evening", distance: "6.8 km" },
];

function Concierge() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <div className="relative h-56 overflow-hidden border-b border-border/40">
        <div className="absolute inset-0 bg-cover bg-center opacity-40" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1800')" }} />
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        <div className="relative mx-auto flex h-full max-w-6xl items-end px-6 pb-6">
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-primary">Concierge</div>
            <h1 className="mt-2 font-display text-4xl sm:text-5xl">Beyond your <span className="text-gradient-gold">suite</span></h1>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-6xl space-y-12 px-6 py-10">
        <Section icon={Compass} title="Tourist Attractions">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {attractions.map((a) => (
              <div key={a.name} className="glass overflow-hidden rounded-2xl hover-lift">
                <div className="h-36 overflow-hidden">
                  <img src={a.img} alt={a.name} loading="lazy" className="h-full w-full object-cover transition hover:scale-105" />
                </div>
                <div className="p-5">
                  <div className="font-display text-lg">{a.name}</div>
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{a.desc}</p>
                  <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" /> {a.distance}</span>
                    <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" /> {a.time}</span>
                  </div>
                  <button className="mt-4 w-full rounded-full bg-primary px-4 py-2 text-xs font-medium text-primary-foreground hover:opacity-90">View details</button>
                </div>
              </div>
            ))}
          </div>
        </Section>

        <Section icon={Film} title="Movie Theatres">
          <div className="grid gap-4 sm:grid-cols-3">
            {cinemas.map((c) => (
              <div key={c.name} className="glass rounded-2xl p-5 hover-lift">
                <div className="font-display text-lg">{c.name}</div>
                <div className="mt-1 text-xs text-muted-foreground inline-flex items-center gap-1"><MapPin className="h-3 w-3" /> {c.distance}</div>
                <p className="mt-3 text-sm text-muted-foreground">Now showing: {c.now}</p>
                <button className="mt-4 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-xs font-medium text-primary-foreground hover:opacity-90">
                  <Ticket className="h-3 w-3" /> Book tickets
                </button>
              </div>
            ))}
          </div>
        </Section>

        <Section icon={Mountain} title="Family Entertainment">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {family.map((f) => (
              <div key={f.name} className="glass rounded-2xl p-5 hover-lift">
                <div className="font-display text-lg">{f.name}</div>
                <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{f.desc}</p>
                <dl className="mt-3 space-y-1 text-xs text-muted-foreground">
                  <div className="flex justify-between"><dt>Distance</dt><dd>{f.distance}</dd></div>
                  <div className="flex justify-between"><dt>Timings</dt><dd>{f.timings}</dd></div>
                  <div className="flex justify-between"><dt>Entry fee</dt><dd className="text-primary">{f.fee}</dd></div>
                </dl>
              </div>
            ))}
          </div>
        </Section>

        <Section icon={Utensils} title="Dining Recommendations">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {dining.map((d) => (
              <div key={d.name} className="glass rounded-2xl p-5 hover-lift">
                <div className="font-display text-lg">{d.name}</div>
                <p className="mt-1 text-sm text-muted-foreground">{d.desc}</p>
                <div className="mt-3 inline-flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="h-3 w-3" /> {d.distance}</div>
              </div>
            ))}
          </div>
        </Section>
      </main>
    </div>
  );
}

function Section({ icon: Icon, title, children }: { icon: typeof Compass; title: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="mb-5 flex items-center gap-3 font-display text-2xl">
        <Icon className="h-5 w-5 text-primary" /> {title}
      </h2>
      {children}
    </section>
  );
}