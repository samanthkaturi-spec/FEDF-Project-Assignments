import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, Clock, ChefHat, Bike, PartyPopper } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/order/$id")({
  head: () => ({ meta: [{ title: "Order Status — Royal Stay" }] }),
  component: () => (<AuthGate><OrderPage /></AuthGate>),
});

type Order = { id: string; status: string; total: number; subtotal: number; gst: number; service_charge: number; room_number: string; notes: string; created_at: string };
type OI = { id: string; name_snapshot: string; quantity: number; price_snapshot: number };

const STEPS = [
  { k: "confirmed", label: "Confirmed", Icon: CheckCircle2 },
  { k: "preparing", label: "Preparing", Icon: ChefHat },
  { k: "out_for_delivery", label: "On the way", Icon: Bike },
  { k: "delivered", label: "Delivered", Icon: PartyPopper },
];

function OrderPage() {
  const { id } = Route.useParams();
  const [order, setOrder] = useState<Order | null>(null);
  const [items, setItems] = useState<OI[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    const [{ data: o }, { data: oi }] = await Promise.all([
      supabase.from("orders").select("*").eq("id", id).maybeSingle(),
      supabase.from("order_items").select("*").eq("order_id", id),
    ]);
    setOrder(o as Order | null);
    setItems((oi as OI[]) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    const ch = supabase
      .channel(`order-${id}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "orders", filter: `id=eq.${id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const activeIdx = order ? Math.max(0, STEPS.findIndex((s) => s.k === order.status)) : 0;

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-6 py-10">
        {loading || !order ? (
          <Skeleton className="h-64 w-full rounded-3xl" />
        ) : (
          <>
            <div className="text-xs uppercase tracking-[0.2em] text-primary">Order tracker</div>
            <h1 className="mt-2 font-display text-4xl">Order #{order.id.slice(0, 6).toUpperCase()}</h1>
            <p className="mt-1 text-sm text-muted-foreground">Room {order.room_number} · placed {new Date(order.created_at).toLocaleString()}</p>

            <div className="mt-8 glass rounded-3xl p-6">
              <div className="flex items-center justify-between">
                {STEPS.map((s, idx) => {
                  const done = idx <= activeIdx;
                  return (
                    <div key={s.k} className="flex flex-1 flex-col items-center text-center">
                      <div className={`grid h-12 w-12 place-items-center rounded-full transition ${done ? "bg-primary text-primary-foreground" : "bg-background/60 text-muted-foreground"}`}>
                        <s.Icon className="h-5 w-5" />
                      </div>
                      <div className={`mt-2 text-xs ${done ? "text-foreground" : "text-muted-foreground"}`}>{s.label}</div>
                      {idx < STEPS.length - 1 && (
                        <div className={`absolute mt-6 hidden h-0.5 w-full ${done ? "bg-primary/40" : "bg-border"}`} />
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" /> Estimated 25–35 min
              </div>
            </div>

            <div className="mt-6 glass rounded-3xl p-6">
              <h2 className="font-display text-xl">Items</h2>
              <ul className="mt-3 divide-y divide-border/30 text-sm">
                {items.map((i) => (
                  <li key={i.id} className="flex justify-between py-3">
                    <span>{i.name_snapshot} × {i.quantity}</span>
                    <span className="text-primary">₹{(Number(i.price_snapshot) * i.quantity).toFixed(0)}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 space-y-1 text-sm">
                <Row label="Subtotal" v={order.subtotal} />
                <Row label="GST" v={order.gst} />
                <Row label="Service" v={order.service_charge} />
                <Row label="Total" v={order.total} bold />
              </div>
              {order.notes && <p className="mt-4 rounded-xl bg-background/40 p-3 text-xs text-muted-foreground">Notes: {order.notes}</p>}
            </div>

            <div className="mt-6 flex gap-3">
              <Link to="/feedback" className="rounded-full glass px-5 py-2.5 text-sm hover:border-primary">Leave feedback</Link>
              <Link to="/dashboard" className="rounded-full bg-primary px-5 py-2.5 text-sm text-primary-foreground hover:opacity-90">Back to dashboard</Link>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
function Row({ label, v, bold }: { label: string; v: number; bold?: boolean }) {
  return (
    <div className={`flex justify-between ${bold ? "font-display text-base text-primary" : "text-muted-foreground"}`}>
      <span>{label}</span><span>₹{Number(v).toFixed(2)}</span>
    </div>
  );
}