import { createFileRoute } from "@tanstack/react-router";
import { AuthGate } from "@/components/site-header";
import { ServicePage } from "@/components/service-page";

export const Route = createFileRoute("/laundry")({
  head: () => ({ meta: [{ title: "Laundry — Royal Stay" }] }),
  component: () => (
    <AuthGate>
      <ServicePage type="laundry" title="Laundry & Pressing" tagline="Pressed to perfection"
        heroImage="https://images.unsplash.com/photo-1545173168-9f1947eebb7f?w=1800"
        hideDuration />
    </AuthGate>
  ),
});