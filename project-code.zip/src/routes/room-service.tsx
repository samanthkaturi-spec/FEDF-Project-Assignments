import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { supabase } from "@/integrations/supabase/client";
import { useCart } from "@/lib/cart";
import { Star, Plus, Minus, ShoppingBag, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export const Route = createFileRoute("/room-service")({
  head: () => ({ meta: [{ title: "Room Service — Royal Stay" }] }),
  component: () => (<AuthGate><RoomService /></AuthGate>),
});

type Cat = { id: string; name: string; slug: string };
type Diet = "veg" | "non_veg" | "vegan";
type Item = { id: string; category_id: string; name: string; description: string; price: number; rating: number; prep_time_min: number; image_url: string; diet_type: Diet };

const DIET_FILTERS: { value: "all" | Diet; label: string; dot: string }[] = [
  { value: "all", label: "All", dot: "bg-primary" },
  { value: "veg", label: "Vegetarian", dot: "bg-emerald-500" },
  { value: "vegan", label: "Vegan", dot: "bg-lime-400" },
  { value: "non_veg", label: "Non-Veg", dot: "bg-rose-500" },
];

const DIET_BADGE: Record<Diet, { label: string; cls: string }> = {
  veg: { label: "Veg", cls: "bg-emerald-500/15 text-emerald-400" },
  vegan: { label: "Vegan", cls: "bg-lime-400/15 text-lime-300" },
  non_veg: { label: "Non-Veg", cls: "bg-rose-500/15 text-rose-400" },
};

function RoomService() {
  const { add, items: cart, setQty, count, total } = useCart();
  const [cats, setCats] = useState<Cat[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [activeCat, setActiveCat] = useState<string>("");
  const [diet, setDiet] = useState<"all" | Diet>("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [{ data: c }, { data: i }] = await Promise.all([
        supabase.from("menu_categories").select("*").order("sort_order"),
        supabase.from("menu_items").select("*").eq("is_available", true).order("name"),
      ]);
      setCats((c as Cat[]) ?? []);
      setItems((i as Item[]) ?? []);
      setActiveCat((c?.[0] as Cat | undefined)?.id ?? "");
      setLoading(false);
    })();
  }, []);

  const qtyOf = (id: string) => cart.find((c) => c.id === id)?.quantity ?? 0;

  const visibleItems = items.filter(
    (i) => i.category_id === activeCat && (diet === "all" || i.diet_type === diet),
  );

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <div
        className="relative h-56 overflow-hidden border-b border-border/40"
      >
        <div className="absolute inset-0 bg-cover bg-center opacity-40"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1800')" }} />
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        <div className="relative mx-auto flex h-full max-w-6xl items-end px-6 pb-6">
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-primary">In-room dining</div>
            <h1 className="mt-2 font-display text-4xl sm:text-5xl">The <span className="text-gradient-gold">Royal Menu</span></h1>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-6xl px-6 py-8 pb-32">
        <div className="mb-4 flex flex-wrap gap-2">
          {DIET_FILTERS.map((f) => (
            <button
              key={f.value}
              onClick={() => setDiet(f.value)}
              className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-medium transition ${
                diet === f.value
                  ? "bg-primary text-primary-foreground"
                  : "glass text-muted-foreground hover:text-foreground"
              }`}
            >
              <span className={`h-2 w-2 rounded-full ${f.dot}`} />
              {f.label}
            </button>
          ))}
        </div>

        <div className="sticky top-16 z-30 -mx-2 mb-6 flex gap-2 overflow-x-auto px-2 py-3 backdrop-blur">
          {loading
            ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-9 w-24 rounded-full" />)
            : cats.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setActiveCat(c.id)}
                  className={`whitespace-nowrap rounded-full px-5 py-2 text-sm transition ${
                    activeCat === c.id
                      ? "bg-primary text-primary-foreground"
                      : "glass text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {c.name}
                </button>
              ))}
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="glass rounded-2xl p-4">
                  <Skeleton className="h-40 w-full rounded-xl" />
                  <Skeleton className="mt-4 h-5 w-2/3" />
                  <Skeleton className="mt-2 h-4 w-full" />
                </div>
              ))
            : visibleItems.length === 0
            ? (
                <div className="col-span-full rounded-2xl glass p-10 text-center text-sm text-muted-foreground">
                  No dishes match this preference in this category.
                </div>
              )
            : visibleItems.map((it) => {
                  const q = qtyOf(it.id);
                  return (
                    <div key={it.id} className="glass overflow-hidden rounded-2xl transition hover-lift">
                      <div className="relative h-44 overflow-hidden">
                        <img src={it.image_url} alt={it.name} loading="lazy"
                          className="h-full w-full object-cover transition duration-500 hover:scale-105" />
                        <div className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-background/80 px-2.5 py-1 text-xs backdrop-blur">
                          <Star className="h-3 w-3 fill-primary text-primary" /> {it.rating.toFixed(1)}
                        </div>
                        <div className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-[10px] font-medium uppercase tracking-wider backdrop-blur ${DIET_BADGE[it.diet_type].cls}`}>
                          {DIET_BADGE[it.diet_type].label}
                        </div>
                      </div>
                      <div className="p-5">
                        <div className="flex items-start justify-between gap-3">
                          <div className="font-display text-lg">{it.name}</div>
                          <div className="font-display text-primary">₹{Number(it.price).toFixed(0)}</div>
                        </div>
                        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{it.description}</p>
                        <div className="mt-3 flex items-center justify-between">
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" /> {it.prep_time_min} min
                          </div>
                          {q > 0 ? (
                            <div className="flex items-center gap-2 rounded-full glass px-1.5 py-1">
                              <button onClick={() => setQty(it.id, q - 1)} className="grid h-7 w-7 place-items-center rounded-full bg-background/60 hover:bg-primary hover:text-primary-foreground">
                                <Minus className="h-3 w-3" />
                              </button>
                              <span className="min-w-5 text-center text-sm">{q}</span>
                              <button onClick={() => setQty(it.id, q + 1)} className="grid h-7 w-7 place-items-center rounded-full bg-background/60 hover:bg-primary hover:text-primary-foreground">
                                <Plus className="h-3 w-3" />
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                add({ id: it.id, name: it.name, price: Number(it.price), image_url: it.image_url });
                                toast.success(`${it.name} added`);
                              }}
                              className="rounded-full bg-primary px-4 py-1.5 text-xs font-medium text-primary-foreground hover:opacity-90"
                            >
                              Add
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
        </div>
      </main>

      {count > 0 && (
        <Link
          to="/cart"
          className="fixed bottom-6 left-1/2 z-40 flex -translate-x-1/2 items-center gap-3 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-2xl hover:opacity-90"
        >
          <ShoppingBag className="h-4 w-4" />
          <span>{count} item{count > 1 ? "s" : ""}</span>
          <span className="opacity-60">|</span>
          <span>₹{total.toFixed(0)}</span>
          <span>View cart →</span>
        </Link>
      )}
    </div>
  );
}