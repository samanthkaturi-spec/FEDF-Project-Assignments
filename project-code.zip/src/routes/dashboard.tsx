import { createFileRoute, Link } from "@tanstack/react-router";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { useAuth } from "@/lib/auth";
import {
  UtensilsCrossed, Sparkles, Shirt, Flower2, Compass,
  ClipboardList, MessageSquare, User as UserIcon
} from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Royal Stay Concierge" }] }),
  component: () => (<AuthGate><Dashboard /></AuthGate>),
});

const tiles = [
  { to: "/room-service", icon: UtensilsCrossed, title: "Room Service", desc: "Curated dining at your door" },
  { to: "/housekeeping", icon: Sparkles, title: "Housekeeping", desc: "Immaculate suite, on demand" },
  { to: "/laundry", icon: Shirt, title: "Laundry", desc: "Pressed, folded, returned" },
  { to: "/spa", icon: Flower2, title: "Spa", desc: "Therapies for body & mind" },
  { to: "/concierge", icon: Compass, title: "Concierge", desc: "Beyond your suite" },
  { to: "/orders", icon: ClipboardList, title: "Order History", desc: "Track every request" },
  { to: "/feedback", icon: MessageSquare, title: "Feedback", desc: "Share your experience" },
  { to: "/profile", icon: UserIcon, title: "Profile", desc: "Your stay details" },
] as const;

function Dashboard() {
  const { profile } = useAuth();
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-6 py-12">
        <div className="mb-10">
          <div className="text-xs uppercase tracking-[0.2em] text-primary">Welcome back</div>
          <h1 className="mt-2 font-display text-4xl sm:text-5xl">
            Good day, <span className="text-gradient-gold">{profile?.full_name?.split(" ")[0] || "Guest"}</span>
          </h1>
          <p className="mt-2 text-muted-foreground">How may we delight you today?</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {tiles.map((t) => (
            <Link
              key={t.to}
              to={t.to}
              className="group relative overflow-hidden rounded-2xl glass p-6 transition-all duration-300 hover-lift hover:border-primary"
            >
              <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/0 to-primary/0 transition-all duration-500 group-hover:from-primary/10" />
              <t.icon className="mb-5 h-7 w-7 text-primary transition-transform duration-300 group-hover:scale-110" />
              <div className="font-display text-xl">{t.title}</div>
              <p className="mt-1 text-sm text-muted-foreground">{t.desc}</p>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}