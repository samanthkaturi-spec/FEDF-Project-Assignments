import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import { Sparkles } from "lucide-react";

export const Route = createFileRoute("/register")({
  head: () => ({ meta: [{ title: "Register — Royal Stay Concierge" }] }),
  component: RegisterPage,
});

function RegisterPage() {
  const { signUp, user } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    full_name: "",
    email: "",
    phone: "",
    room_number: "",
    password: "",
    confirm: "",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) navigate({ to: "/dashboard", replace: true });
  }, [user, navigate]);

  function set<K extends keyof typeof form>(k: K, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (form.full_name.trim().length < 2) return toast.error("Please enter your full name");
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return toast.error("Enter a valid email");
    if (!/^[0-9 +\-()]{7,20}$/.test(form.phone)) return toast.error("Enter a valid mobile number");
    if (!form.room_number.trim()) return toast.error("Room number is required");
    if (form.password.length < 6) return toast.error("Password must be at least 6 characters");
    if (form.password !== form.confirm) return toast.error("Passwords do not match");
    setLoading(true);
    const { error } = await signUp({
      email: form.email.trim(),
      password: form.password,
      full_name: form.full_name.trim(),
      phone: form.phone.trim(),
      room_number: form.room_number.trim(),
    });
    setLoading(false);
    if (error) return toast.error(error);
    toast.success("Welcome to Royal Stay — your suite is ready");
    navigate({ to: "/dashboard", replace: true });
  }

  return (
    <div className="relative min-h-screen">
      <div className="absolute inset-0 -z-10 bg-cover bg-center opacity-30"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1600')" }} />
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-background/80 to-background" />
      <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6 py-12">
        <Link to="/" className="mb-8 flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
          <Sparkles className="h-4 w-4 text-primary" /> Royal Stay Concierge
        </Link>
        <div className="glass rounded-3xl p-8">
          <h1 className="font-display text-3xl">Register your suite</h1>
          <p className="mt-1 text-sm text-muted-foreground">A few details to begin your stay.</p>
          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <Field label="Full Name">
              <input required value={form.full_name} onChange={(e) => set("full_name", e.target.value)} className={inputCls} />
            </Field>
            <Field label="Email Address">
              <input type="email" required value={form.email} onChange={(e) => set("email", e.target.value)} className={inputCls} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Mobile Number">
                <input required value={form.phone} onChange={(e) => set("phone", e.target.value)} className={inputCls} />
              </Field>
              <Field label="Room Number">
                <input required value={form.room_number} onChange={(e) => set("room_number", e.target.value)} className={inputCls} />
              </Field>
            </div>
            <Field label="Password">
              <input type="password" required value={form.password} onChange={(e) => set("password", e.target.value)} className={inputCls} />
            </Field>
            <Field label="Confirm Password">
              <input type="password" required value={form.confirm} onChange={(e) => set("confirm", e.target.value)} className={inputCls} />
            </Field>
            <button disabled={loading} className="mt-2 w-full rounded-full bg-primary py-3 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-60">
              {loading ? "Creating your suite…" : "Begin your stay"}
            </button>
          </form>
          <p className="mt-6 text-center text-sm text-muted-foreground">
            Already a guest? <Link to="/login" className="text-primary hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

const inputCls = "mt-1 w-full rounded-xl border border-border bg-background/40 px-4 py-2.5 text-sm outline-none focus:border-primary";
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}