import { createFileRoute } from "@tanstack/react-router";
import { AuthGate } from "@/components/site-header";
import { ServicePage } from "@/components/service-page";

export const Route = createFileRoute("/housekeeping")({
  head: () => ({ meta: [{ title: "Housekeeping — Royal Stay" }] }),
  component: () => (
    <AuthGate>
      <ServicePage type="housekeeping" title="Housekeeping" tagline="Immaculate suite"
        heroImage="https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=1800" />
    </AuthGate>
  ),
});