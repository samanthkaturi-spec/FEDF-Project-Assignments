import { createFileRoute } from "@tanstack/react-router";
import { AuthGate } from "@/components/site-header";
import { ServicePage } from "@/components/service-page";

export const Route = createFileRoute("/spa")({
  head: () => ({ meta: [{ title: "Spa — Royal Stay" }] }),
  component: () => (
    <AuthGate>
      <ServicePage type="spa" title="Spa & Wellness" tagline="Body & mind"
        heroImage="https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=1800" />
    </AuthGate>
  ),
});