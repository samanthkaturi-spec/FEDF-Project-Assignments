import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/orders")({
  head: () => ({ meta: [{ title: "Order History — Royal Stay" }] }),
  component: () => (<AuthGate><OrdersPage /></AuthGate>),
});

type Order = { id: string; status: string; total: number; created_at: string; room_number: string };

function OrdersPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[] | null>(null);

  useEffect(() => {
    if (!user) return;
    supabase.from("orders").select("*").eq("user_id", user.id).order("created_at", { ascending: false })
      .then(({ data }) => setOrders((data as Order[]) ?? []));
  }, [user]);

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-4xl px-6 py-10">
        <h1 className="mb-8 font-display text-4xl">Order <span className="text-gradient-gold">history</span></h1>
        {!orders ? (
          <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-2xl" />)}</div>
        ) : orders.length === 0 ? (
          <div className="glass grid place-items-center rounded-3xl py-20 text-muted-foreground">
            No orders yet.
            <Link to="/room-service" className="mt-4 rounded-full bg-primary px-5 py-2 text-sm text-primary-foreground">Order something</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map((o) => (
              <Link key={o.id} to="/order/$id" params={{ id: o.id }}
                className="glass flex items-center justify-between rounded-2xl p-5 transition hover-lift hover:border-primary">
                <div>
                  <div className="font-display text-lg">Order #{o.id.slice(0, 6).toUpperCase()}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString()} · Room {o.room_number}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs uppercase tracking-wider text-primary">{o.status.replace(/_/g, " ")}</div>
                  <div className="font-display text-xl">₹{Number(o.total).toFixed(0)}</div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}