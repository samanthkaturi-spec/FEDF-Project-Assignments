import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Star } from "lucide-react";

export const Route = createFileRoute("/feedback")({
  head: () => ({ meta: [{ title: "Feedback — Royal Stay" }] }),
  component: () => (<AuthGate><Feedback /></AuthGate>),
});

function Feedback() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [food, setFood] = useState(5);
  const [service, setService] = useState(5);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    const { error } = await supabase.from("feedback").insert({
      user_id: user.id, food_rating: food, service_rating: service, comment,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Thank you for your feedback");
    navigate({ to: "/dashboard" });
  }

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-2xl px-6 py-10">
        <h1 className="font-display text-4xl">Share your <span className="text-gradient-gold">experience</span></h1>
        <p className="mt-2 text-muted-foreground">Your words shape our service.</p>
        <form onSubmit={submit} className="glass mt-8 space-y-6 rounded-3xl p-6">
          <Rating label="Food quality" value={food} onChange={setFood} />
          <Rating label="Service" value={service} onChange={setService} />
          <label className="block">
            <span className="text-xs uppercase tracking-wider text-muted-foreground">Your comments</span>
            <textarea rows={5} value={comment} onChange={(e) => setComment(e.target.value)} required
              className="mt-1 w-full rounded-xl border border-border bg-background/40 px-4 py-2.5 text-sm outline-none focus:border-primary" />
          </label>
          <button disabled={busy} className="w-full rounded-full bg-primary py-3 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-60">
            {busy ? "Submitting…" : "Submit feedback"}
          </button>
        </form>
      </main>
    </div>
  );
}

function Rating({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-2 flex gap-1">
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} type="button" onClick={() => onChange(n)} className="p-1">
            <Star className={`h-7 w-7 ${n <= value ? "fill-primary text-primary" : "text-muted-foreground"}`} />
          </button>
        ))}
      </div>
    </div>
  );
}