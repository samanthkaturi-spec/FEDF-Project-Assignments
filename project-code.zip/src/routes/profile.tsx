import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AuthGate, SiteHeader } from "@/components/site-header";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Pencil, X } from "lucide-react";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Profile — Royal Stay" }] }),
  component: () => (<AuthGate><Profile /></AuthGate>),
});

function Profile() {
  const { profile, user, refreshProfile } = useAuth();
  const [form, setForm] = useState({ full_name: "", phone: "", room_number: "" });
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    if (profile) setForm({ full_name: profile.full_name, phone: profile.phone, room_number: profile.room_number });
  }, [profile]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    const { error } = await supabase.from("profiles").update(form).eq("id", user.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    await refreshProfile();
    toast.success("Profile updated");
    setEditing(false);
  }

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-2xl px-6 py-10">
        <h1 className="font-display text-4xl">Your <span className="text-gradient-gold">profile</span></h1>
        <div className="mt-6 flex items-center gap-4 rounded-2xl glass p-5">
          <div className="grid h-14 w-14 place-items-center rounded-full bg-primary/15 font-display text-xl text-primary">
            {(profile?.full_name?.[0] || "G").toUpperCase()}
          </div>
          <div>
            <div className="font-display text-lg">{profile?.full_name || "Guest"}</div>
            <div className="text-xs text-muted-foreground">{profile?.email}</div>
          </div>
        </div>

        {!editing ? (
          <div className="glass mt-6 space-y-5 rounded-3xl p-6">
            <InfoRow label="Full name" value={profile?.full_name || "—"} />
            <InfoRow label="Email address" value={profile?.email || "—"} />
            <InfoRow label="Mobile" value={profile?.phone || "—"} />
            <InfoRow label="Room number" value={profile?.room_number || "—"} />
            <button
              onClick={() => setEditing(true)}
              className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3 text-sm font-medium text-primary-foreground hover:opacity-90"
            >
              <Pencil className="h-4 w-4" /> Edit details
            </button>
          </div>
        ) : (
          <form onSubmit={save} className="glass mt-6 space-y-4 rounded-3xl p-6">
            <Field label="Full name">
              <input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} className={inputCls} />
            </Field>
            <Field label="Mobile">
              <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputCls} />
            </Field>
            <Field label="Room number">
              <input value={form.room_number} onChange={(e) => setForm({ ...form, room_number: e.target.value })} className={inputCls} />
            </Field>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => {
                  setEditing(false);
                  if (profile) setForm({ full_name: profile.full_name, phone: profile.phone, room_number: profile.room_number });
                }}
                className="flex-1 inline-flex items-center justify-center gap-2 rounded-full glass py-3 text-sm"
              >
                <X className="h-4 w-4" /> Cancel
              </button>
              <button disabled={busy} className="flex-1 rounded-full bg-primary py-3 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-60">
                {busy ? "Saving…" : "Save changes"}
              </button>
            </div>
          </form>
        )}
      </main>
    </div>
  );
}
const inputCls = "mt-1 w-full rounded-xl border border-border bg-background/40 px-4 py-2.5 text-sm outline-none focus:border-primary";
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 border-b border-border/40 pb-3 last:border-0 last:pb-0">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      <span className="text-base">{value}</span>
    </div>
  );
}